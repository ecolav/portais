import TCPClient from './module/tcpUhf';

export const chainwayApi = TCPClient;