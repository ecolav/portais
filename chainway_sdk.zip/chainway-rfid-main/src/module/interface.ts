interface RFID {
    epc? : string,
    tid? : string,
    ant? : number,
    rssi? : string
}

export type { RFID }